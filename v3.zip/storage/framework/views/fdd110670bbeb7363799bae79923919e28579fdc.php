<?php $__env->startSection('title', "تعديل طالب"); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جميع الطلاب"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/students"); ?>
        <?php $__env->slot('page_now', "تعديل طالب"); ?>
    <?php echo $__env->renderComponent(); ?>

    <form action="<?php echo e(route('students.update', $student->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-12">
                <?php if($errors->any()): ?>
                    <p class="text-danger"><?php echo e($errors->first()); ?></p>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>تعديل طالب </h4>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="number" class="control-label required">رقم الطالب:</label>
                                <input type="text" class="form-control" name="number" id="number" placeholder="أدخل رقم الطالب"
                                       value="<?php echo e($student->number); ?>" required>
                                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="name" class="control-label required">اسم الطالب:</label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="أدخل اسم الطالب"
                                       value="<?php echo e($student->name); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="guardian_name" class="control-label required">اسم ولي الأمر:</label>
                                <input type="text" class="form-control" name="guardian_name" id="guardian_name" placeholder="أدخل اسم ولي الأمر"
                                       value="<?php echo e($student->guardian->name); ?>" required>
                                <?php $__errorArgs = ['guardian_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="guardian_phone" class="control-label required">رقم هاتف ولي الأمر:</label>
                                <input type="text" class="form-control" name="guardian_phone" id="guardian_phone" placeholder="أدخل رقم هاتف ولي الأمر"
                                       value="<?php echo e($student->guardian->phone); ?>" required>
                                <?php $__errorArgs = ['guardian_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="guardian_attribute"> صفة ولي الامر:</label>
                                <input type="text" class="form-control" name="guardian_attribute" id="guardian_attribute" placeholder="أدخل  صفة ولي الامر"
                                       value="<?php echo e($student->guardian->attribute); ?>">
                                <?php $__errorArgs = ['guardian_attribute'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="class" class="control-label required">الصف:</label>
                                <input type="text" class="form-control" name="class" id="class" placeholder="أدخل الصف"
                                       value="<?php echo e($student->class); ?>" required>
                                <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="teacher" class="control-label required">المدرس:</label>
                                <select class="select2 form-control" required
                                        data-placeholder="اختر المدرس" name="teacher" id="teacher">
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($teacher->id); ?>"
                                                <?php echo e($teacher_id ===  $teacher->id ? 'selected' : null); ?>

                                                data-idcat="<?php echo e($teacher->id); ?>">
                                            <?php echo e($teacher->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="mentor" class="control-label required">المرشد:</label>
                                <select class="select2 form-control" required
                                        data-placeholder="اختر المرشد" name="mentor" id="mentor">
                                    <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($mentor->id); ?>"
                                                <?php echo e($mentor_id ===  $mentor->id ? 'selected' : null); ?>

                                                data-idcat="<?php echo e($mentor->id); ?>">
                                            <?php echo e($mentor->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="nationality">الجنسية:</label>
                                <input type="text" class="form-control" name="nationality" id="nationality" placeholder="أدخل الجنسية"
                                       value="<?php echo e($student->nationality); ?>">
                                <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="age">العمر:</label>
                                <input type="number" class="form-control" name="age" id="age" placeholder="أدخل العمر"
                                       value="<?php echo e($student->age); ?>">
                                <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="notes">ملاحظات:</label>
                                <textarea class="form-control" id="notes" rows="2"><?php echo e($student->notes); ?></textarea>
                                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary" id="button-send">
                                    تعديل
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/students/edit.blade.php ENDPATH**/ ?>
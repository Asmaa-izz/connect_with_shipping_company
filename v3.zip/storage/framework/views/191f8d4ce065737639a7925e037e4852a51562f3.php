<?php $__env->startSection('title', " جلسة ارشادية لطالب  ". $student->name); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جلسات ارشادية للطلاب"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/guidance-sessions"); ?>
        <?php $__env->slot('page_now',  " جلسة ارشادية لطالب ". $student->name); ?>
    <?php echo $__env->renderComponent(); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>سجل زيارة أولياء أمور لطالب
                                <strong><?php echo e($student->name); ?></strong>
                                صاحب رقم
                                <strong><?php echo e($student->number); ?></strong>
                            </h4>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>النوع :</strong> <span><?php echo e($session->type); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>المكان :</strong> <span><?php echo e($session->place); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>الوقت :</strong> <span><?php echo e(\Carbon\Carbon::parse($session->time)->format('d/m/Y')); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>الوصف :</strong> <span><?php echo e($session->description); ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/records/guidance-session/show.blade.php ENDPATH**/ ?>
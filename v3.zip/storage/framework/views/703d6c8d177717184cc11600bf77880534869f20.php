        <!-- JAVASCRIPT -->
        <script src="<?php echo e(URL::asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/libs/bootstrap/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/libs/metismenu/metismenu.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('assets/libs/node-waves/node-waves.min.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>

        <!-- App js -->
        <script src="<?php echo e(URL::asset('assets/js/app.min.js')); ?>"></script>
        
        <?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/auth/layouts/footerScript.blade.php ENDPATH**/ ?>
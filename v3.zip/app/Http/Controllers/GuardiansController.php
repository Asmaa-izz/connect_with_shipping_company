<?php

namespace App\Http\Controllers;

use App\Models\Guardian;
use Illuminate\Http\Request;

class GuardiansController extends Controller
{
    public function index()
    {

    }

    public function create()
    {
    }

    public function store(Request $request)
    {
    }

    public function show(Guardian $guardian)
    {
    }

    public function edit(Guardian $guardian)
    {
    }

    public function update(Request $request, Guardian $guardian)
    {
    }

    public function destroy(Guardian $guardian)
    {
    }
}

<?php $__env->startSection('title', "اضافة سجل متابعة المواقف اليومية"); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جميع الطلاب"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/students"); ?>
        <?php $__env->slot('page_now', "اضافة سجل متابعة المواقف اليومية"); ?>
    <?php echo $__env->renderComponent(); ?>

    <form action="<?php echo e(route('record-follow-up.store', $student->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <p class="text-danger"><?php echo e($errors->first()); ?></p>
                        <?php endif; ?>

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>اضافة سجل متابعة المواقف اليومية الطارئ
                                <strong><?php echo e($student->name); ?></strong>
                                صاحب رقم
                                <strong><?php echo e($student->number); ?></strong>
                            </h4>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="status" class="control-label required">الحالة:</label>
                                <select class="select2 form-control" required
                                        data-placeholder="اختر " name="status">
                                    <option value="نفسية" selected>نفسية</option>
                                    <option value="تربوية">تربوية</option>
                                    <option value="صحية">صحية</option>
                                    <option value="سلوكية">سلوكية</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="class" class="control-label required">الصف:</label>
                                <input type="text" class="form-control" name="class" id="class"
                                       placeholder="أدخل الصف"
                                       value="<?php echo e($student->class); ?>" required>
                                <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="description_situation">وصف الموقف:</label>
                                <textarea class="form-control" id="description_situation" rows="2"
                                          name="description_situation"></textarea>
                                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="handle_situation">معالجة الموقف:</label>
                                <textarea class="form-control" id="handle_situation" rows="2"
                                          name="handle_situation"></textarea>
                                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="show_in_noun"
                                           name="show_in_noun">
                                    <label class="form-check-label" for="show_in_noun">الرصد في نون:</label>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary" id="button-send">
                                    اضافة
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/records/follow-up/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', "إضافة شركة شحن جديد"); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جميع شركات الشحن"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/companies"); ?>
        <?php $__env->slot('page_now', "إضافة شركة شحن جديد"); ?>
    <?php echo $__env->renderComponent(); ?>

    <form action="<?php echo e(route('companies.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <p class="text-danger"><?php echo e($errors->first()); ?></p>
                        <?php endif; ?>

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>إضافة  شركة شحن جديد</h4>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-12">ب
                                <label for="name" class="control-label required">اسم شركة الشحن:</label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="أدخل الاسم"
                                       value="<?php echo e(old('name')); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="city" class="control-label required">المحافظة :</label>
                                    <select class="select2 form-control" required
                                            data-placeholder="اختر " name="city_id" id="city">
                                        <option></option>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="area" class="control-label required">المناطق المتاحة :</label>
                                    <select class="select2 form-control" required multiple="multiple"
                                            data-placeholder="اختر " name="areas[]" id="area">
                                    </select>
                                </div>
                            </div>


                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary" id="button-send">
                                    حفظ
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>

    <script>

        $('#city').select2();
        $('#area').select2();

        $(document).on("change", "#city", function () {
            let city = $(this).val();
            $('#area').select2({
                ajax: {
                    url: `/dashboard/cities/${city}?hasCompany=true`,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: params.term, // search term
                            page: params.page
                        };
                    },
                    processResults: function (data) {
                        console.log(data.data)
                        return {
                            results: $.map(data.data, function (item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            })
                        };
                    }
                },
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/connect_with_shipping_company/resources/views/dashboard/companies/create.blade.php ENDPATH**/ ?>
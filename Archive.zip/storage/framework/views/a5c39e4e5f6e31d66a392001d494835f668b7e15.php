<?php $__env->startSection('title'); ?> لوحة التحكم <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
<?php $__env->slot('page_now', "الرئيسية"); ?>
<?php echo $__env->renderComponent(); ?>
    <div class="row">
        <div class="col-xl-3 col-sm-6 col-12">
            <div class="card bg-soft-primary">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="media-body text-left">
                                <h3 class="success"><?php echo e($employees_count); ?></h3>
                                <span>عدد الموظفين</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6 col-12">
            <div class="card bg-soft-info">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="media-body text-left">
                                <h3 class="success"><?php echo e($orders_count); ?></h3>
                                <span>عدد الطلبات</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-sm-6 col-12">
            <div class="card bg-soft-warning">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="media-body text-left">
                                <h3 class="success"><?php echo e($companies_count); ?></h3>
                                <span>عدد شركات الشحن</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/connect_with_shipping_company/resources/views/dashboard/index.blade.php ENDPATH**/ ?>
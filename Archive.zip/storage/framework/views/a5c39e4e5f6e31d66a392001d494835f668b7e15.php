<?php $__env->startSection('title'); ?> لوحة التحكم <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
<?php $__env->slot('page_now', "الرئيسية"); ?>
<?php echo $__env->renderComponent(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/connect_with_shipping_company/resources/views/dashboard/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'المحافظات'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets/libs/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets/css/loading-spinner-overlay.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "الشحن"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/shipping"); ?>
        <?php $__env->slot('page_now', "المحافظات"); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title d-flex justify-content-between align-items-center my-3">
                        <h4>جميع المحافظات</h4>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#creat-city">
                            إضافة محافظة جديد
                        </button>
                    </div>
                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap"
                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>عدد المناطق التابعة</th>
                            <th>العمليات</th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
    </div>

    <div class="modal fade" id="creat-city" tabindex="-1" role="dialog" aria-labelledby="creatRoleLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="creatRoleLabel">اضافة محافظة جديدة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-create" action="<?php echo e(route('cities.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="control-label required">اسم المحافظة </label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                    <button type="button" class="btn btn-primary"
                            onclick="event.preventDefault(); document.getElementById('form-create').submit();">اضافة
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="edit-city" tabindex="-1" role="dialog" aria-labelledby="creatRoleLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="creatRoleLabel">تعديل محافظة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="form-edit" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name_edit" class="control-label required">اسم المحافظة </label>
                            <input type="text" class="form-control" name="name" id="name_edit" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                        <button type="submit" class="btn btn-primary">تعديل
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#datatable').DataTable({
                // processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('cities.index')); ?>",
                columns: [
                    {"data": "name"},
                    {"data": "areas_count"},
                    {"data": "action"},
                ],
            });
        });


        function deleteItem(id) {
            Swal.fire({
                title: 'هل أنت متأكد من عملية الحذف ؟',
                text: "تنبيه , لا يمكن استعادة البيانات",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم , احذف!',
                cancelButtonText: 'إلفاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    $("div.spanner").addClass("show");
                    $("div.overlay").addClass("show");
                    fetch(`/dashboard/cities/${id}`, {
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
                        },
                        method: "delete",
                    })
                        .then(response => location = window.location)
                        .catch(error => console.log("error : " + error));
                }
            })

        }

        $(document).on("click", ".edit-item", function () {
            let cityId = $(this).data('id');
            console.log(cityId)
            let cityName = $(this).data('name');
            $("#name_edit").val(cityName);
            $('#form-edit').attr('action', '/dashboard/cities/' + cityId);
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/connect_with_shipping_company/resources/views/dashboard/shipping/cities/index.blade.php ENDPATH**/ ?>
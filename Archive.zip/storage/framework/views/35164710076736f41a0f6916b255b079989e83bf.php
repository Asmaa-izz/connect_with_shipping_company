<?php $__env->startSection('title', "إضافة طلب جديد"); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جميع طلبات"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/orders"); ?>
        <?php $__env->slot('page_now', "إضافة طلب جديد"); ?>
    <?php echo $__env->renderComponent(); ?>

    <form action="<?php echo e(route('orders.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <p class="text-danger"><?php echo e($errors->first()); ?></p>
                        <?php endif; ?>

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>إضافة طلب جديد</h4>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="number" class="control-label required">رقم الطلب:</label>
                                <input type="text" class="form-control" name="number" id="number"
                                       placeholder="أدخل رقم الطلب"
                                       value="<?php echo e(old('number') ?? $number); ?>" required>
                                <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="customer_name" class="control-label required">اسم العميل:</label>
                                <input type="text" class="form-control" name="customer_name" id="customer_name"
                                       placeholder="أدخل اسم العميل"
                                       value="<?php echo e(old('customer_name')); ?>" required>
                                <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="customer_phone" class="control-label required">هاتف العميل:</label>
                                <input type="text" class="form-control" name="customer_phone" id="customer_phone"
                                       placeholder="أدخل هاتف العميل"
                                       value="<?php echo e(old('customer_phone')); ?>" required>
                                <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="customer_phone_other" class="control-label required">رقم هاتف أخر:</label>
                                <input type="text" class="form-control" name="customer_phone_other"
                                       id="customer_phone_other" placeholder="أدخل رقم هاتف أخر"
                                       value="<?php echo e(old('customer_phone_other')); ?>" required>
                                <?php $__errorArgs = ['customer_phone_other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="city" class="control-label required">المحافظة :</label>
                                <select class="select2 form-control" required
                                        data-placeholder="اختر " name="city_id" id="city">
                                    <option></option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="area" class="control-label required">المنطقة :</label>
                                <select class="select2 form-control" required
                                        data-placeholder="اختر " name="area_id" id="area">
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="neighborhood" class="control-label required">الحي :</label>
                                <select class="select2 form-control" required
                                        data-placeholder="اختر " name="neighborhood_id" id="neighborhood">
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="amount" class="control-label required">المبلغ:</label>
                                <input type="number" class="form-control" name="amount" id="amount"
                                       placeholder="أدخل المبلغ"
                                       value="<?php echo e(old('amount')); ?>" required>
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="product_details" class="control-label required"> التفاصيل:</label>
                                <textarea class="form-control" id="product_details" rows="2"
                                          name="product_details"><?php echo e(old('product_details')); ?></textarea>
                                <?php $__errorArgs = ['product_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary" id="button-send">
                                    حفظ
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/libs/select2/select2.min.js')); ?>"></script>

    <script>
        $('#city').select2();
        $(document).on("change", "#city", function () {
            let city = $(this).val();
            $('#area').select2({
                ajax: {
                    url: `/dashboard/cities/${city}`,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: params.term, // search term
                            page: params.page
                        };
                    },
                    processResults: function (data) {
                        console.log(data.data)
                        return {
                            results: $.map(data.data, function (item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            })
                        };
                    }
                },
            });
        });

        $(document).on("change", "#area", function () {
            let area = $(this).val();
            $('#neighborhood').select2({
                ajax: {
                    url: `/dashboard/areas/${area}`,
                    dataType: 'json',
                    data: function (params) {
                        return {
                            q: params.term, // search term
                            page: params.page
                        };
                    },
                    processResults: function (data) {
                        console.log(data.data)
                        return {
                            results: $.map(data.data, function (item) {
                                return {
                                    text: item.name,
                                    id: item.id
                                }
                            })
                        };
                    }
                },
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/connect_with_shipping_company/resources/views/dashboard/orders/create.blade.php ENDPATH**/ ?>
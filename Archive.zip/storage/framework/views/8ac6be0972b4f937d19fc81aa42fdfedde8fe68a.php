<?php echo $__env->yieldContent('css'); ?>

<!-- App css -->
<link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-light" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(URL::asset('assets/css/app-rtl.min.css')); ?>" id="app-rtl" rel="stylesheet" type="text/css" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;400;700&display=swap" rel="stylesheet">

<?php echo $__env->yieldContent('css'); ?>

<style>
    .required.control-label:after {
        content:"*";
        color:red;
    }
</style>
<?php /**PATH /Users/asmaa/php_projects/connect_with_shipping_company/resources/views/dashboard/layouts/head.blade.php ENDPATH**/ ?>
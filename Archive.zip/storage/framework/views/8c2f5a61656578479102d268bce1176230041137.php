<?php $__env->startSection('title', $teacher->name); ?>


<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "جميع المدرسين"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/teachers"); ?>
        <?php $__env->slot('page_now', $teacher->name); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title m-3"><strong><?php echo e($teacher->name); ?></strong></h3>
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <strong>البريد الالكتورني :</strong> <span><?php echo e($teacher->email); ?></span>
                                </li>
                                <li class="list-group-item">
                                    <strong>عدد طلابه :</strong> <span><?php echo e($teacherـstudent_count); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>


    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/teachers/show.blade.php ENDPATH**/ ?>
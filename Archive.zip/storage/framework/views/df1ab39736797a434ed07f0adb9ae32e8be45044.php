<?php $__env->startSection('title', 'الصلاحيات'); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets/libs/select2/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(URL::asset('assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(URL::asset('assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.css')); ?>">
    <link href="<?php echo e(URL::asset('assets/libs/bootstrap-timepicker/bootstrap-timepicker.min.css')); ?>" rel="stylesheet"
          type="text/css">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(URL::asset('assets/libs/bootstrap-touchspin/bootstrap-touchspin.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::asset('assets/libs/datepicker/datepicker.min.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('page_now', "الصلاحيات"); ?>
    <?php echo $__env->renderComponent(); ?>

    <div class="card">
        <div class="card-body">

            <div class="d-flex justify-content-between">
                <h4 class="card-title">الصلاحيات</h4>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#creatRole">إنشاء
                </button>
            </div>
            <br>
            <div id="accordion">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-1 shadow-none">
                        <div class="card-header" id="headingOne">
                            <div class="d-flex justify-content-between align-items-center">
                                <h6 class="m-0">
                                    <a href="#<?php echo e($role->name); ?>" class="text-dark" data-toggle="collapse" aria-expanded="false"
                                       aria-controls="collapseOne">
                                        <?php echo e($role->name); ?>

                                    </a>
                                </h6>

                                <?php if($role->id > 1): ?>
                                    <div class="d-flex">
                                        <form id="delete-<?php echo e($role->id); ?>" action="/dashboard/roles/<?php echo e($role->id); ?>" method="POST"
                                              style="display:none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                        <button type="button" class="btn p-0" data-toggle="modal" data-target="#a<?php echo e($role->id); ?>">
                                            <i class="mdi mdi-delete-empty text-danger mdi-24px"></i>
                                        </button>
                                        <button type="button" class="btn" data-toggle="modal" data-target="#edit-<?php echo e($role->id); ?>">
                                            تعديل
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div id="<?php echo e($role->name); ?>" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                            <div class="card-body">
                                <ul>
                                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($ability->name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- sample modal content -->
                    <div id="a<?php echo e($role->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title mt-0" id="myModalLabel">تأكيد
                                        العملية</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    هل أنت متأكد من الحذف
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal">إغلاق
                                    </button>
                                    <button type="button" class="btn btn-danger waves-effect waves-light"
                                            onclick="event.preventDefault(); document.getElementById('delete-<?php echo e($role->id); ?>').submit();">
                                        حذف
                                    </button>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                    
                    <div class="modal fade" id="edit-<?php echo e($role->id); ?>" tabindex="-1" role="dialog"
                         aria-labelledby="edit-<?php echo e($role->id); ?>Label" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="edit-<?php echo e($role->id); ?>Label">تعديل صلاحية <?php echo e($role->name); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form id="form-edit-role-<?php echo e($role->id); ?>" action="/dashboard/roles/<?php echo e($role->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <div class="form-group">
                                            <label for="formrow-firstname-input">اسم الصلاحية </label>
                                            <input type="text" class="form-control" id="formrow-firstname-input" name="name"
                                                   value="<?php echo e($role->name); ?>">
                                        </div>

                                        <div class="docs-toggles overflow-auto" style="height: 50vh">
                                            <ul class="list-group">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="list-group-item">
                                                        <div class="form-check">
                                                            <input class="form-check-input" id="<?php echo e($ability->id); ?>" type="checkbox"
                                                                   name="ability[]" value="<?php echo e($ability->id); ?>"
                                                                <?php echo e($role->permissions->map->id->contains($ability->id) ? 'checked' : ''); ?>>
                                                            <label class="form-check-label"
                                                                   for="<?php echo e($ability->id); ?>"><?php echo e($ability->name); ?></label>
                                                        </div>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>

                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                                    <button type="button" class="btn btn-primary"
                                            onclick="event.preventDefault(); document.getElementById('form-edit-role-<?php echo e($role->id); ?>').submit();">
                                        حفظ
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

    <div class="modal fade" id="creatRole" tabindex="-1" role="dialog" aria-labelledby="creatRoleLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="creatRoleLabel">إنشاء صلاحية جديدة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-create-role" action="/dashboard/roles" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="formrow-firstname-input">اسم الصلاحية </label>
                            <input type="text" class="form-control" id="formrow-firstname-input" name="name">
                        </div>

                        <div class="docs-toggles overflow-auto" style="height: 50vh">
                            <ul class="list-group">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <div class="form-check">
                                            <input class="form-check-input" id="<?php echo e($ability->id); ?>" type="checkbox"
                                                   name="ability[]" value="<?php echo e($ability->id); ?>">
                                            <label class="form-check-label" for="<?php echo e($ability->id); ?>"><?php echo e($ability->name); ?></label>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                    <button type="button" class="btn btn-primary"
                            onclick="event.preventDefault(); document.getElementById('form-create-role').submit();">حفظ
                    </button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <!-- Plugins js -->
    <script src="<?php echo e(URL::asset('assets/libs/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/pdfmake/pdfmake.min.js')); ?>"></script>

    <!-- Init js-->
    <script src="<?php echo e(URL::asset('assets/js/pages/datatables.init.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('assets/libs/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/bootstrap-timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/bootstrap-touchspin/bootstrap-touchspin.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/libs/datepicker/datepicker.min.js')); ?>"></script>

    <script src="<?php echo e(URL::asset('assets/js/pages/form-advanced.init.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/roles/index.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-light" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL::asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL::asset('assets/css/app-rtl.min.css')); ?>" id="app-rtl" rel="stylesheet" type="text/css"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;400;700&display=swap" rel="stylesheet">
    <title>تقرير</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        @font-face {
            font-family: 'Cairo';
            font-style: normal;
            font-weight: normal;
            src: url('https://fonts.googleapis.com/css2?family=Cairo&display=swap') format('truetype');
        }

        body {
            font-family: Cairo, DejaVu Sans, sans-serif;
            direction: rtl;
            text-align: right;
        }

        .list-group-item {
            border: none;
        }
    </style>
</head>
<body>
<div class="m-5">
    <div class="container-fluid">
        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title m-3"><strong> تقرير الطالب : <?php echo e($student->name); ?></strong></h3>
                        <div class="row">
                            <div class="col-md-4">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>رقم الطالب :</strong> <span><?php echo e($student->number); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>الجنسية :</strong> <span><?php echo e($student->nationality); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>العمر :</strong> <span><?php echo e($student->age); ?></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>اسم ولي الأمر :</strong> <span><?php echo e($student->guardian->name); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>رقم هاتف ولي الأمر :</strong>
                                        <span><?php echo e($student->guardian->phone); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>صفة ولي الأمر :</strong>
                                        <span><?php echo e($student->guardian->attribute); ?></span>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>الصف :</strong> <span><?php echo e($student->class); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>المدرس :</strong> <span><?php echo e($teacher); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>المرشد :</strong> <span><?php echo e($mentor); ?></span>
                                    </li>
                                </ul>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title m-3"><strong>سجل متابعة زيارات أولياء الأمور
                                [<?php echo e($visitsRecord->count()); ?>]
                                زيارة</strong></h3>
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $visitsRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="list-group list-group-flush mb-3">
                                        <li class="list-group-item">
                                            <strong>اسم ولي الأمر :</strong> <span><?php echo e($record->guardian_name); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>رقم هاتف ولي الأمر :</strong> <span><?php echo e($record->phone); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>صفة ولي الأمر :</strong>
                                            <span><?php echo e($record->guardian_attribute); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>التاريخ :</strong>
                                            <span><?php echo e(\Carbon\Carbon::parse($record->created_at)->format('d/m/Y')); ?></span>
                                        </li>
                                        <li class="list-group-item <?php if(!$loop->last): ?> border-bottom <?php endif; ?>">
                                            <strong>ملاحظات :</strong> <span><?php echo e($record->notes); ?></span>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title m-3"><strong>سجل متابعة المواقف اليومية
                                [<?php echo e($followUpRecord->count()); ?>]
                                مواقف</strong></h3>
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $followUpRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="list-group list-group-flush mb-3">
                                        <li class="list-group-item">
                                            <strong>الصف :</strong> <span><?php echo e($student->class); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>نوع الحالة :</strong> <span><?php echo e($record->status); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>مصدر الحالة :</strong> <span><?php echo e($record->status_source); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>اسم مصدر الحالة :</strong> <span><?php echo e($record->user->name); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>التاريخ :</strong>
                                            <span><?php echo e(\Carbon\Carbon::parse($record->created_at)->format('d/m/Y')); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>وصف الموقف :</strong>
                                            <span><?php echo e($record->description_situation); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>معالجة الموقف :</strong>
                                            <span><?php echo e($record->handle_situation); ?></span>
                                        </li>
                                        <li class="list-group-item <?php if(!$loop->last): ?> border-bottom <?php endif; ?>">
                                            <strong>الرصد في نون :</strong>
                                            <span><?php echo e($record->show_in_noun ? 'نعم' : 'لا'); ?></span>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title m-3"><strong>الجلسات التأخر الدراسي
                                [<?php echo e($guidanceSession_lag->count()); ?>]
                                جلسة</strong></h3>
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $guidanceSession_lag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <strong>المكان :</strong> <span><?php echo e($session->place); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>الوقت :</strong>
                                            <span><?php echo e(\Carbon\Carbon::parse($session->time)->format('d/m/Y')); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>الوصف :</strong> <span><?php echo e($session->description); ?></span>
                                        </li>
                                    </ul>
                                    <?php if(!$loop->last): ?>
                                        <div style="border: 1px solid #000" class="border-bottom"></div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title m-3"><strong>الجلسات السلوك العدواني
                                [<?php echo e($guidanceSession_behavior->count()); ?>]
                                جلسة</strong></h3>
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $guidanceSession_behavior; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="list-group list-group-flush mb-3">
                                        <li class="list-group-item">
                                            <strong>المكان :</strong> <span><?php echo e($session->place); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>الوقت :</strong>
                                            <span><?php echo e(\Carbon\Carbon::parse($session->time)->format('d/m/Y')); ?></span>
                                        </li>
                                        <li class="list-group-item <?php if(!$loop->last): ?> border-bottom <?php endif; ?>">
                                            <strong>الوصف :</strong> <span><?php echo e($session->description); ?></span>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </div>
</div>


<script type="text/javascript">
    window.print();

</script>
</body>
</html>
<?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/report/index.blade.php ENDPATH**/ ?>
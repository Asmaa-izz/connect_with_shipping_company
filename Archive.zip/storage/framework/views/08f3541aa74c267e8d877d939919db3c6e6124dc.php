<?php $__env->startSection('title', " سجل متابعة المواقف اليومية لطالب ". $student->name); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('dashboard.commonComponents.breadcrumb'); ?>
        <?php $__env->slot('li_1', "الرئيسية"); ?>
        <?php $__env->slot('li_1_link', "/dashboard"); ?>
        <?php $__env->slot('li_2', "سجلات متابعة المواقف اليومية"); ?>
        <?php $__env->slot('li_2_link', "/dashboard/record-follow-up"); ?>
        <?php $__env->slot('page_now',  " سجل متابعة المواقف اليومية لطالب ". $student->name); ?>
    <?php echo $__env->renderComponent(); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <div class="card-title d-flex justify-content-between align-items-center my-3">
                            <h4>سجلات متابعة المواقف اليومية
                                <strong><?php echo e($student->name); ?></strong>
                                صاحب رقم
                                <strong><?php echo e($student->number); ?></strong>
                            </h4>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>الصف :</strong> <span><?php echo e($student->class); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>نوع الحالة :</strong> <span><?php echo e($record->status); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>مصدر الحالة :</strong> <span><?php echo e($record->status_source); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>اسم مصدر الحالة :</strong> <span><?php echo e($record->user->name); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>التاريخ :</strong> <span><?php echo e(\Carbon\Carbon::parse($record->created_at)->format('d/m/Y')); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>وصف الموقف :</strong> <span><?php echo e($record->description_situation); ?></span>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>معالجة الموقف :</strong> <span><?php echo e($record->handle_situation); ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asmaa/php_projects/JT/resources/views/dashboard/records/follow-up/show.blade.php ENDPATH**/ ?>